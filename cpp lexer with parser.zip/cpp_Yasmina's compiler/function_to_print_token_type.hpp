

#ifndef function_to_print_token_type_hpp
#define function_to_print_token_type_hpp
#include "lexer.hpp"
#include <stdio.h>

void printTokenType(Token token);

#endif /* function_to_print_token_type_hpp */
