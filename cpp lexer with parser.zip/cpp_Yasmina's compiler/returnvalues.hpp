#ifndef RETURN_TOKEN_TYPE_HPP
#define RETURN_TOKEN_TYPE_HPP

#include "lexer.hpp"
#include <string>

std::string returnTokenType(Token token);

#endif /* RETURN_TOKEN_TYPE_HPP */
